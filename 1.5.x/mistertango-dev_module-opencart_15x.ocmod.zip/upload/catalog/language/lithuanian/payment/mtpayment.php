<?php

// Text
$_['text_title'] = 'Per internetinę bankininkystę (Swedbank, SEB, DNB ir kiti)';
$_['text_instruction'] = 'MisterTango instrukcija';
$_['text_description'] = 'Pasirinkite MisterTango mokėjimo būdą ir atlikite pavedimą.';
$_['text_payment'] = 'Laukiame apmokėjimo.';
$_['text_amount_received'] = 'Iš viso gauta';
$_['text_email_message'] = 'El. paštu Jums išsiuntėme išankstinę sąskaitą. Jei dar neapmokėjote ir norite pasirinkti kitą mokėjimo būdą - ';
$_['text_click_here'] = 'spauskite čia';
