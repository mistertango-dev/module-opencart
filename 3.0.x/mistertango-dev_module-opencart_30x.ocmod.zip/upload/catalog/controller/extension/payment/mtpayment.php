<?php

/**
 * Class ControllerExtensionPaymentMTPayment
 */
class ControllerExtensionPaymentMTPayment extends Controller
{

    /**
     * @return mixed
     */
    public function index()
    {
        $this->load->language('extension/payment/mtpayment');

        $this->load->model('extension/payment/mtpayment');

        $data['text_instruction'] = $this->language->get('text_instruction');
        $data['text_description'] = $this->language->get('text_description');
        $data['text_payment'] = $this->language->get('text_payment');

        $data['button_confirm'] = $this->language->get('button_confirm');

        $data['mtpayment_username'] = $this->config->get('payment_mtpayment_username');
        $data['mtpayment_callback_url'] = $this->model_extension_payment_mtpayment->getCallbackUrl();
        $data['mtpayment_url_data'] = '/index.php?route=extension/payment/mtpayment/data';
        $data['mtpayment_url_confirm'] = '/index.php?route=extension/payment/mtpayment/confirm';
        $data['mtpayment_url_history'] = '/index.php?route=extension/payment/mtpayment/history';

        $data['continue'] = $this->url->link('checkout/success');

        $data['arg_time'] = time();

        return $this->load->view('extension/payment/mtpayment_payment', $data);
    }

    /**
     *
     */
    public function data()
    {
        $this->response->addHeader('Content-Type: application/json');

        $customer_email = $this->customer->getEmail();
        if (
            empty($customer_email)
            && isset($this->session->data['guest'])
            && isset($this->session->data['guest']['email'])
            && !empty($this->session->data['guest']['email'])
        ) {
            $customer_email = $this->session->data['guest']['email'];
        }

        $order_id = null;
        if (!empty($this->request->get['order']) && $this->request->get['order'] != 'null') {
            $order_id = $this->request->get['order'];
        } elseif (!empty($this->session->data['order_id'])) {
            $order_id = $this->session->data['order_id'];
        }

        if (empty($order_id)) {
            $this->response->setOutput(json_encode(array(
                'success' => false,
                'error' => 'Order is not present',
            )));

            return;
        }

        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($order_id);

        if (empty($customer_email) && isset($order_info['email'])) {
            $customer_email = $order_info['email'];
        }

        if (empty($customer_email)) {
            $this->response->setOutput(json_encode(array(
                'success' => false,
                'error' => 'Unknown customer',
            )));

            return;
        }

        $websocket_query = $this->db->query(
            "SELECT * FROM " . DB_PREFIX . "mttransactions WHERE `order` = '" . (int)$order_info['order_id'] . "'"
        );

        if ($websocket_query->num_rows) {
            $websocket_id = $websocket_query->row['websocket'];
        } else {
            $websocket_id = null;
        }

        $total = trim(strip_tags($this->currency->format(
            $order_info['total'],
            $order_info['currency_code'],
            '',
            false
        )));
        $this->response->setOutput(json_encode(array(
            'success' => true,
            'websocket' => $websocket_id,
            'transaction' => $this->session->data['order_id'] . '_' . time(),
            'customer' => $customer_email,
            'amount' => $total,
            'currency' => $order_info['currency_code'],
            'language' => $this->language->get('code'),
        )));
    }

    /**
     *
     */
    public function confirm()
    {
        $this->response->addHeader('Content-Type: application/json');

        $order_id = null;

        if (!empty($this->session->data['order_id'])) {
            $order_id = $this->session->data['order_id'];
        }

        if (!empty($this->request->get['order'])) {
            $order_id = $this->request->get['order'];
        }

        $transaction = isset($this->request->get['transaction']) ? $this->request->get['transaction'] : null;
        $websocket = isset($this->request->get['websocket']) ? $this->request->get['websocket'] : null;
        $amount = isset($this->request->get['amount']) ? $this->request->get['amount'] : null;
        $offline = isset($this->request->get['offline']) ? $this->request->get['offline'] : false;

        if (empty($transaction) || empty($websocket) || empty($amount)) {
            $this->response->setOutput(json_encode(array(
                'success' => false,
                'error' => 'Invalid parameters',
            )));

            return;
        }

        $this->load->model('checkout/order');

        $order_info = array();

        if (isset($order_id)) {
            $order_info = $this->model_checkout_order->getOrder($order_id);
        }

        if ($order_info['payment_code'] == 'mtpayment') {
            $this->load->language('extension/payment/mtpayment');

            $this->load->model('extension/payment/mtpayment');

            $this->model_extension_payment_mtpayment->validateOrder($transaction, $amount, $websocket);

            $this->response->setOutput(json_encode(array(
                'success' => true,
                'order' => $order_info['order_id']
            )));

            return;
        }

        $this->response->setOutput(json_encode(array(
            'success' => false,
            'error' => 'Invalid transaction'
        )));
    }

    /**
     *
     */
    public function history()
    {
        $this->load->language('account/order');
        $this->load->language('extension/payment/mtpayment');

        $this->load->model('checkout/order');
        $this->load->model('extension/payment/mtpayment');

        $order_id = isset($this->request->get['order']) ? $this->request->get['order'] : null;

        $data = array(
            'order_id' => $order_id,
            'histories' => $this->histories(array(), false)
        );

        $data['text_history'] = $this->language->get('text_history');

        $data['mtpayment_username'] = $this->config->get('payment_mtpayment_username');
        $data['mtpayment_callback_url'] = $this->model_extension_payment_mtpayment->getCallbackUrl();
        $data['mtpayment_url_data'] = '/index.php?route=extension/payment/mtpayment/data';
        $data['mtpayment_url_confirm'] = '/index.php?route=extension/payment/mtpayment/confirm';
        $data['mtpayment_url_history'] = '/index.php?route=extension/payment/mtpayment/history';
        $data['mtpayment_url_histories'] = '/index.php?route=extension/payment/mtpayment/histories';

        $this->document->setTitle($this->language->get('text_order'));

        $data['heading_title'] = $this->language->get('text_order');

        $data['text_error'] = $this->language->get('text_error');

        $data['button_continue'] = $this->language->get('button_continue');

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account', '', 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('account/order', '', 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_order'),
            'href' => '/index.php?route=extension/payment/mtpayment/history&order=' . $order_id
        );

        $data['continue'] = '/index.php?route=extension/payment/mtpayment/history';
        if (isset($this->session->data['order_id'])) {
            $data['continue'] = $this->url->link('checkout/success');
        }

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $data['arg_time'] = time();

        $this->response->setOutput($this->load->view('extension/payment/mtpayment_history', $data));
    }

    /**
     * @param array $params
     * @param bool|true $json
     * @return null|string
     */
    public function histories($params = array(), $json = true)
    {
        $this->load->language('account/order');
        $this->load->language('extension/payment/mtpayment');

        $html = '';

        $data = array(
            'histories' => array()
        );

        $order_id = isset($this->request->get['order']) ? $this->request->get['order'] : null;

        if (isset($order_id)) {
            $this->load->model('account/order');

            $data['text_email_message'] = $this->language->get('text_email_message');
            $data['text_click_here'] = $this->language->get('text_click_here');

            $data['column_date_added'] = $this->language->get('column_date_added');
            $data['column_status'] = $this->language->get('column_status');
            $data['column_comment'] = $this->language->get('column_comment');

            $order_pending_status_id = $this->config->get('payment_mtpayment_order_pending_status_id');

            $order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_pending_status_id . "' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");

            if ($order_status_query->num_rows) {
                $order_pending_status = $order_status_query->row['name'];
            } else {
                $order_pending_status = '';
            }

            $data['order_id'] = $order_id;
            $data['order_pending_status'] = $order_pending_status;

            $results = $this->model_account_order->getOrderHistories($order_id);

            $allow_different_payment = true;

            foreach ($results as $result) {
                $data['histories'][] = array(
                    'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
                    'status' => $result['status'],
                    'comment' => $result['notify'] ? nl2br($result['comment']) : ''
                );

                if ($result['status'] != $order_pending_status) {
                    $allow_different_payment = false;
                }
            }

            $data['allow_different_payment'] = $allow_different_payment;

						if( ! $this->customer->isLogged() && ( ! isset( $this->session->data['order_id'] ) || $this->session->data['order_id'] != $order_id ) ) {
							$data = array(
			            'histories' => array(),
			        );
						}

            $html = $this->load->view('extension/payment/mtpayment_histories', $data);
        }

        if ($json) {
            $this->response->setOutput(json_encode(array(
                'success' => true,
                'html_table_order_histories' => $html
            )));

            return null;
        }

        return $html;
    }

    /**
     *
     */
    public function callback()
    {
        $this->load->model('extension/payment/mtpayment');

        $hash = isset($this->request->post['hash']) ? $this->request->post['hash'] : false;

        if ($hash !== false) {
            $data = json_decode(
                $this->model_extension_payment_mtpayment->decrypt($hash, $this->config->get('payment_mtpayment_secret_key'))
            );
            $data->custom = isset($data->custom) ? json_decode($data->custom) : null;

            if (!isset($data->custom) && !isset($data->custom->description)) {
                die('Bad custom data and description');
            }

            $transaction = explode('_', $data->custom->description);

            if (count($transaction) != 2) {
                die('Invalid transaction ID');
            }

            if ($this->model_extension_payment_mtpayment->existsCallback($data->callback_uuid)) {
                die('OK');
            }

            try {
                $transaction_id = implode('_', $transaction);

                $success = $this->model_extension_payment_mtpayment->closeOrder(
                    $transaction_id,
                    $data->custom->data->amount
                );
            } catch (Exception $e) {
                die('System was unable to close order');
            }

            if ($success) {
                $this->model_extension_payment_mtpayment->insertCallback($data);
                die('OK');
            }
        }

        die('No hash data');
    }
}
