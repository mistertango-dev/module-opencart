<?php

// Text
$_['text_title'] = 'Via internet banking (Swedbank, SEB, DNB etc.)';
$_['text_instruction'] = 'MisterTango Instructions';
$_['text_description'] = 'Please choose MisterTango payment method and make payment.';
$_['text_payment'] = 'Your order will not ship until we receive payment.';
$_['text_amount_received'] = 'Amount received';
$_['text_email_message'] = 'Check your email, we sent you an invoice. If you wish to use other methods for payment - ';
$_['text_click_here'] = 'click here';
